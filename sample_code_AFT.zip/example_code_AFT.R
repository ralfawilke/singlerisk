# This is sample code for the approach suggested in Lo, S.M.S. and Wilke, R.A. (2022): A single risk approach to the semiparametric copula competing risks model, Working Paper.
# In particular, it is sample estimation code for the AFT model.

# It requires LHS00.csv which is a sample data file. It contains 5,000 observations randomly selected from the original LFS data file of size 21,919.

# Set relevant parameters under ##### SETUP #####

rm(list = ls())

#install.packages("copula")
#install.packages(c("survival", "survminer"))
#install.packages("scatterplot3d")
#install.packages("cmprsk")
#install.packages("pastecs")
#install.packages("plyr") 

library(pastecs)
library(cmprsk)
library(timereg)
library(MALDIquant)
library(copula)
library(survival)
library(plyr)
library(dplyr)
library(readxl)


########## SETUP  ##########

data0 <- read.csv("C:/ENTERPATH/LFS00.csv") ## input data file
model = "llog" ## choose the model "expo" "weib" ""llog"
t<-data0$dur # input the name of duration variable 
z1<-data0$edu # input the name of covariate
delw = 2-data0$left  # input the name of risk indicator risk 1 = 1, risk 2 = 0  
rep = 50  # bootstrap sample 

############################
dat0 <- data.frame(t,delw,z1) # data frame containing all relevant data
n <- nrow(data0)
k <- 2 # dimensions
tqlim <- 1 # when plotting the graph, max is quantile of tqlim

# to fine cge, we define some functions regarding the copula generator
invpsiclayton <- function(s, tau){  # inverse copula generator of clayton
  if (tau==0){
    u <- exp(-s)
  }  
  if (tau!=0){
    theta <- iTau(archmCopula("clayton"), tau)
    u <- (theta*s+1)^(-1/theta)
  }
  return(u)
}
dpsiclayton <- function(s, tau){  # derivative of copula generator of clayton
  if (tau==0){
    u<--1/s
  }  
  if (tau!=0){
    theta <- iTau(archmCopula("clayton"), tau)
    u <- -s^(-1-theta)
  }
  return(u)
}
dinvpsiclayton <- function(s, tau){  # derivative of inverse generator of clayton
  if (tau==0){
    u<- -exp(-s)
  }  
  if (tau!=0){
    theta <- iTau(archmCopula("clayton"), tau)
    u <- -(1+theta*s)^(-1-1/theta)
  } 
  return(u)
}
psiclayton<-function(s,tau){ # copula generator of clayton
  if (tau==0){
    
    u<- -log(s)
  }
  if (tau!=0){
    theta <- iTau(archmCopula("clayton"), tau)
    
    u<-(s^(-theta)-1)/theta
  }
  return(u)
}
cgeclayton <- function(q1, q2, f, dt, tau){ # cge using clayton
  
  if (tau==0){
    u<- exp(-cumsum(f/(1-q1-q2)*dt))
  }
  if (tau!=0){
    
    u<- invpsiclayton(-cumsum(dpsiclayton(1-q1-q2,tau)*f*dt), tau)
  }
  return(u)
}
simfc <- function(tau, k, n){ 
  if (tau==0){
    u<-matrix(runif(k*n),ncol=k)
    return(u)
  }
  if (tau!=0){
    theta <- iTau(archmCopula("clayton"), tau)
    u <- rCopula(n, claytonCopula(theta, dim = k)) #  u1, u2 are the marginal from Clayton
    return(u)
  }
}
# we define the function for log-logistic distribution with covariate z
llogistic <- function(t,z, a, b , beta){  # survival function
  u<-(1+(exp(z*beta)*t/a)^(b))^(-1)
}
## b = 1/sigma, a = 1/lambda
dllogistic <- function(t,z, a, b, beta){ # hazard function
  u <- ((b/a)*(exp(z*beta)*t/a)^(b-1))/(1+(exp(z*beta)*t/a)^b)
}
invllogistic <- function(u,z,a, b, beta){
  t = a*exp(-z*beta)*(u^(-1)-1)^(1/b)
}
# we define the function for weibull distribution with covariate z
weib <- function(t,z, a, b , beta){  # survival function
  u<-exp(-(a*t)^b*exp(z*beta))
}
dweib <- function(t,z, a, b, beta){ # hazard function
  u <- a^b*b*exp(z*beta)*t^(b-1)*exp(-(a*t)^b*exp(z*beta))
}
invweib <- function(u,z,a, b, beta){
  t = (-log(u)/a^b/exp(z*beta))^(1/b)
}
# we define the function for expo distribution with covariate z
expo <- function(t,z, a, beta){  # survival function
  u<-exp(-a*t*exp(z*beta))
}
dexpo <- function(t,z, a,beta){ # hazard function
  u <- a*exp(z*beta)*exp(-a*t*exp(z*beta))
}

invexpo <- function(u,z,a,beta){
  t = -log(u)/a/exp(z*beta)
}
# start bootstap
sims <- function(){
  x <- 1:n
 M<- sample(x, replace=TRUE) # length 2
  dat <- dat0[M,]
  summary(dat)

### START OPTIM and search for tau ###
# we need Qj and to estimate CGE.
  dat<-dat[order(dat$t),] # sort the data with t
  dat0<-dat[which(dat[,3]==0),] # data with z=0
  dat1<-dat[which(dat[,3]==1),] # data with z=1

  q0 <-cuminc(dat0[,1],dat0[,2]) # time grid is not the same as original data  point
  tp0 <-timepoints(q0,dat0[,1]) # change the time grid to original data point
  eQ0<-unname(t(tp0[[1]])) # combine with t, delta, z
  
  q1 <-cuminc(dat1[,1],dat1[,2]) # time grid is not the same as original data  point
  tp1 <-timepoints(q1,dat1[,1]) # change the time grid to original data point
  eQ1<-unname(t(tp1[[1]])) # combine with t, delta, z
  
  for(i in 1:dim(eQ0)[2]){
    eQ0[is.na(eQ0[,i]),i] <- -Inf  # Q has Na at the end of the column, so replace it to -inf
    eQ0[is.infinite(eQ0[,i]),i] <- max(eQ0[,i])  # replace -inf to max of the column, i.e. Q(infty)
    eQ1[is.na(eQ1[,i]),i] <- -Inf  # Q has Na at the end of the column, so replace it to -inf
    eQ1[is.infinite(eQ1[,i]),i] <- max(eQ1[,i])  # replace -inf to max of the column, i.e. Q(infty)
  }
  
  #vectors and matrices with unique time points and estimates
  ut0<-as.data.frame(unique(dat0[,1]))
  ut0<-rbind(rep(0,1),ut0) # add row of zeros as the first row
  eQ0_1<-rbind(rep(0,1),eQ0) # add row of zeros as the first row
  
  dt0<-diff(ut0[,1],lag=1)  # ti - t_{i-1} 
  ef0<-diff(eQ0_1,lag=1)/dt0 # first different of Qj = fj: add zero as first observation
  #ef0[is.na(ef0)] <- 0
  
  ut1<-as.data.frame(unique(dat1[,1]))
  ut1<-rbind(rep(0,1),ut1) # add row of zeros as the first row
  eQ1_1<-rbind(rep(0,1),eQ1) # add row of zeros as the first row
  
  dt1<-diff(ut1[,1],lag=1)  # ti - t_{i-1} 
  ef1<-diff(eQ1_1,lag=1)/dt1 # first different of Qj = fj: add zero as first observation
  
  ut0<-as.data.frame(unique(dat0[,1])) # unique time points without leading 0
  ut1<-as.data.frame(unique(dat1[,1])) # unique time points without leading 0
  
  #create matrices of zeros
  eQ0full<-matrix(0, ncol = dim(eQ0)[2] , nrow = length(dat0[,1]))
  eQ1full<-matrix(0, ncol = dim(eQ0)[2], nrow = length(dat1[,1]))
  ef0full<-matrix(0, ncol = dim(eQ0)[2] , nrow = length(dat0[,1]))
  ef1full<-matrix(0, ncol = dim(eQ0)[2], nrow = length(dat1[,1]))
  dt0full<-matrix(0, 1, nrow = length(dat0[,1]))
  dt1full<-matrix(0, 1, nrow = length(dat1[,1]))
  
  # create matrices of t, eQ and ef with row dimension equaling the number of observations.
  for(i in 1:dim(ut0)[1]){
    I0<-which(dat0[,1]==ut0[i,1])
    for(j in 1:k){
      eQ0full[I0,j]<-eQ0[i,j]
      ef0full[I0,j]<-ef0[i,j]
    }
    dt0full[I0,1]<-dt0[i]
  }
  
  for(i in 1:dim(ut1)[1]){
    I1<-which(dat1[,1]==ut1[i,1])
    for(j in 1:k){
      eQ1full[I1,j]<-eQ1[i,j]
      ef1full[I1,j]<-ef1[i,j]
    }
    dt1full[I1,1]<-dt1[i]
  }
  
  datQ0<-data.frame(dat0,eQ0full,ef0full,dt0full) # check the data of Qj
  datQ1<-data.frame(dat1,eQ1full,ef1full,dt1full) # check the data of Qj

opttau <- function(etau){
# compute the estimated CGE

  datQ0u<-datQ0
  datQ1u<-datQ1
  
  datQ0u<-invisible(datQ0u %>% select(-2, -3))
  datQ1u<-invisible(datQ1u %>% select(-2, -3))
  
  datQ0u<-as.data.frame(unique(datQ0u)) # for unique t
  datQ1u<-as.data.frame(unique(datQ1u)) # for unique t
  
  ecgew0u = cgeclayton(datQ0u[,2],datQ0u[,3],datQ0u[,4],datQ0u[,6], etau)
  ecgew1u = cgeclayton(datQ1u[,2],datQ1u[,3],datQ1u[,4],datQ1u[,6], etau)
  
  ecgew0u[is.na(ecgew0u)] <- Inf  # ecgew has Na at the end of the column, so replace it to -inf
  ecgew0u[is.infinite(ecgew0u)] <- min(ecgew0u)  # replace -inf to max of the column, i.e. Q(infty)
  ecgew1u[is.na(ecgew1u)] <- Inf  # ecgew has Na at the end of the column, so replace it to -inf
  ecgew1u[is.infinite(ecgew1u)] <- min(ecgew1u)  # replace -inf to max of the column, i.e. Q(infty)
  
  #inflate row length of ecgew0u and 1u back to all observations
  #create matrices of zeros
  ecgew0<-matrix(0, ncol = 1 , nrow = length(dat0[,1]))
  ecgew1<-matrix(0, ncol = 1, nrow = length(dat1[,1]))
  
  for(i in 1:length(ecgew0u)){
    I0<-which(datQ0[,1]==datQ0u[i,1])
    ecgew0[I0]<-ecgew0u[i]
  }
  
  for(i in 1:length(ecgew1u)){
    I1<-which(datQ1[,1]==datQ1u[i,1])
    ecgew1[I1]<-ecgew1u[i]
  }
  
  # estimate alpha using regression
  ecgew<-c(ecgew0,ecgew1)
  
  datQ<- data.frame(rbind.fill(datQ0 , datQ1),ecgew) # group z=0 and z =1 into one single data 
  y <- log(datQ$t) # tranform t to log(t)
  y[which(is.infinite(y))]<-NaN
  
  if (model == "expo") {
    lcge<- log(-log(datQ$ecgew)) # transform ecge to log(-log)
    lcge[which(is.infinite(lcge))]<-NaN
    y<-y-lcge
    z1 <- datQ$z1
    datlm<-data.frame(y,z1) # run regression need a data frame
    fit<-lm(formula =y ~ z1 ) # regress log(t)-log(-log(cge)) on z, nn constant
    eaw<-exp(-fit$coefficients[[1]])
    eb1w<- -fit$coefficients[[2]]
    eSemiw0 <- exp(-datQ0[,1]*eaw*exp(datQ0[,3]*eb1w))
    eSemiw1 <- exp(-datQ1[,1]*eaw*exp(datQ1[,3]*eb1w))
  }
  if (model == "weib") {
    lcge<- log(-log(datQ$ecgew)) # transform ecge to log(-log)
    lcge[which(is.infinite(lcge))]<-NaN
    z1 <- datQ$z1
    datlm<-data.frame(y,lcge,z1) # run regression need a dataframe
    fit<-lm(formula =y ~ z1 + lcge ) # regress log(t) on log(-log(cge)), z, ann constant
    ebw <- 1/fit$coefficients[[3]] # parameter transformation
    eaw<-exp(-fit$coefficients[[1]])  # parameter transformation
    eb1w<- -fit$coefficients[[2]]*ebw  # parameter transformation
    eSemiw0 <- exp(-(datQ0[,1]*eaw)^ebw*exp(datQ0[,3]*eb1w))  # construct Sj implie by the semimodel
    eSemiw1 <- exp(-(datQ1[,1]*eaw)^ebw*exp(datQ1[,3]*eb1w))
  }
  if (model == "llog") {
    lcge<- log(datQ$ecgew/(1-datQ$ecgew)) # transform ecge to log(s/(1-s))
    lcge[which(is.infinite(lcge))]<-NaN
    z1 <- datQ$z1
    datlm<-data.frame(y,lcge,z1) # run regression need a dataframe
    fit<-lm(formula =y ~ z1 + lcge ) # regress log(t) on log(-log(cge)), z, ann constant
    ebw <- -1/fit$coefficients[[3]] # parameter transformation
    eaw<- 1/exp(-fit$coefficients[[1]])  # parameter transformation
    eb1w<- -fit$coefficients[[2]]  # parameter transformation
    eSemiw0 <- 1/(1+(datQ0[,1]/eaw*exp(datQ0[,3]*eb1w))^ebw)
    eSemiw1 <- 1/(1+(datQ1[,1]/eaw*exp(datQ1[,3]*eb1w))^ebw)
  }
  eSemiw0[is.na(eSemiw0)] <- Inf  # eSemi has Na at the end of the column, so replace it to -inf
  eSemiw0[is.infinite(eSemiw0)] <- min(eSemiw0)  # replace -inf to max of the column, i.e. Q(infty)
  eSemiw1[is.na(eSemiw1)] <- Inf  # eSemi has Na at the end of the column, so replace it to -inf
  eSemiw1[is.infinite(eSemiw1)] <- min(eSemiw1)  # replace -inf to max of the column, i.e. Q(infty)
  sum((ecgew0-eSemiw0)^2) + sum((ecgew1-eSemiw1)^2) #  objective function is the mean squared sum error
  
}
f1<-optimize(opttau, interval=c(-0.9,0.9), tol=0.0000001, maximum=FALSE)

# estimate parameter from regression using the esimated tau
datQ0u<-datQ0
datQ1u<-datQ1
datQ0u<-invisible(datQ0u %>% select(-2, -3))
datQ1u<-invisible(datQ1u %>% select(-2, -3))
datQ0u<-as.data.frame(unique(datQ0u)) # for unique t
datQ1u<-as.data.frame(unique(datQ1u)) # for unique t
ecgew0u = cgeclayton(datQ0u[,2],datQ0u[,3],datQ0u[,4],datQ0u[,6], f1$minimum)
ecgew1u = cgeclayton(datQ1u[,2],datQ1u[,3],datQ1u[,4],datQ1u[,6], f1$minimum)
ecgew0u[is.na(ecgew0u)] <- Inf  # ecgew has Na at the end of the column, so replace it to -inf
ecgew0u[is.infinite(ecgew0u)] <- min(ecgew0u)  # replace -inf to max of the column, i.e. Q(infty)
ecgew1u[is.na(ecgew1u)] <- Inf  # ecgew has Na at the end of the column, so replace it to -inf
ecgew1u[is.infinite(ecgew1u)] <- min(ecgew1u)  # replace -inf to max of the column, i.e. Q(infty)
#inflate row length of ecgew0u and 1u back to all observations
#create matrices of zeros
ecgew0<-matrix(0, ncol = 1 , nrow = length(dat0[,1]))
ecgew1<-matrix(0, ncol = 1, nrow = length(dat1[,1]))
for(i in 1:length(ecgew0u)){
  I0<-which(datQ0[,1]==datQ0u[i,1])
  ecgew0[I0]<-ecgew0u[i]
}
for(i in 1:length(ecgew1u)){
  I1<-which(datQ1[,1]==datQ1u[i,1])
  ecgew1[I1]<-ecgew1u[i]
}
# estimate alpha using regression
ecgew<-c(ecgew0,ecgew1)
datQ<- data.frame(rbind.fill(datQ0 , datQ1),ecgew) # group z=0 and z =1 into one single data 
y <- log(datQ$t)
y[which(is.infinite(y))]<-NaN
if (model == "expo") {
  lcge<- log(-log(datQ$ecgew)) # transform ecge to log(-log)
  lcge[which(is.infinite(lcge))]<-NaN
  y<-y-lcge
  z1 <- datQ$z1
  datlm<-data.frame(y, z1) # run regression need a dataframe
  fit<-lm(formula =y ~ z1  ) # regress log(t) on log(-log(cge)), z, ann constant
  eb1w <- -fit$coefficients[[2]] # parameter transformation
  eaw<-exp(-fit$coefficients[[1]])  # parameter transformation
  etau = f1$minimum
}
if (model == "weib") {
  lcge<- log(-log(datQ$ecgew)) # transform ecge to log(-log)
  lcge[which(is.infinite(lcge))]<-NaN
  z1 <- datQ$z1
  datlm<-data.frame(y,lcge,z1) # run regression need a dataframe
  fit<-lm(formula =y ~ z1 + lcge ) # regress log(t) on log(-log(cge)), z, ann constant
  ebw <- 1/fit$coefficients[[3]] # parameter transformation
  eaw<-exp(-fit$coefficients[[1]])  # parameter transformation
  eb1w<- -fit$coefficients[[2]]*ebw  # parameter transformation
  etau = f1$minimum
}
  if (model == "llog") {  
  lcge<- log(datQ$ecgew/(1-datQ$ecgew)) # transform ecge to log(s/(1-s))
  lcge[which(is.infinite(lcge))]<-NaN
  z1 <- datQ$z1
  datlm<-data.frame(y,lcge,z1) # run regression need a dataframe
  fit<-lm(formula =y ~ z1 + lcge ) # regress log(t) on log(-log(cge)), z, ann constant
  ebw <- -1/fit$coefficients[[3]] # parameter transformation
  eaw<- 1/exp(-fit$coefficients[[1]])  # parameter transformation
  eb1w<- -fit$coefficients[[2]]  # parameter transformation\
  etau = f1$minimum
  }
if (model != "expo") { 
res <- list(etaub = etau, eawb = eaw, ebwb = ebw, ebeta1wb=eb1w)
}
if (model == "expo") { 
  res <- list(etaub = etau, eawb = eaw, ebeta1wb=eb1w)
}

return(res)
}


res2 <- vector("list", rep)
for(i in 1:rep) res2[[i]] <- try(sims(), TRUE)
res3<-res2[sapply(res2, function(x) !inherits(x, "try-error"))]

etaub<-rep(0,length(res3)) # create data frame for estimated beta
ebeta1wb<-rep(0,length(res3)) # create data frame for estimated beta
eawb<-rep(0,length(res3)) # create data frame for estimated beta
ebwb<-rep(0,length(res3)) # create data frame for estimated beta

if (model!="expo"){
for (i in 1:length(res3)){
  etaub[i]<-res3[[i]][[1]]
  eawb[i]<-res3[[i]][[2]]  
  ebwb[i]<-res3[[i]][[3]]
  ebeta1wb[i]<-res3[[i]][[4]]
}
}
if (model=="expo"){
  for (i in 1:length(res3)){
    etaub[i]<-res3[[i]][[1]]
    eawb[i]<-res3[[i]][[2]]  
    ebeta1wb[i]<-res3[[i]][[3]]
  }
} 

mtau = mean(etaub)
Vtau = mean((etaub-mean(etaub))^2)
maw = mean(eawb)
Vaw = mean((eawb-mean(eawb))^2)
if (model!="expo"){
mbw = mean(ebwb)
Vbw = mean((ebwb-mean(ebwb))^2)
}
mbeta1w = mean(ebeta1wb)
Vbeta1w = mean((ebeta1wb-mean(ebeta1wb))^2)

############### report
n  # number of observations
rep  # bootstrap sample

mtau # estimated tau
Vtau # variance for tau
quantile(etaub,0.025) # CI for etau
quantile(etaub,0.975) # CI for etau

maw # estimated alpha
Vaw # variance for alpha
quantile(eawb,0.025) # CI for alpha
quantile(eawb,0.975) # CI for alpha

if (model!="expo"){
mbw # estimated sigma
Vbw # variance for sigma
quantile(ebwb,0.025) # CI for sigma
quantile(ebwb,0.975) # CI for sigma
}

mbeta1w # estimated beta
Vbeta1w # variance for beta
quantile(ebeta1wb,0.025) # CI for beta
quantile(ebeta1wb,0.975) # CI for beta
